var searchData=
[
  ['ftat_0',['ftAt',['../classdominio_1_1clases_1_1_content_based.html#a78dbed395df5211421b8ecd94cce1308',1,'dominio.clases.ContentBased.ftAt()'],['../classdominio_1_1clases_1_1_distance_items.html#ab3bd08effaf5fd173aa4dc658e60e5e3',1,'dominio.clases.DistanceItems.ftAt()'],['../classdominio_1_1clases_1_1_recomendacion.html#af74a229683857258d811d63caa7debc6',1,'dominio.clases.Recomendacion.ftAt()']]]
];
