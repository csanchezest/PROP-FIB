var searchData=
[
  ['slopeone_0',['SlopeOne',['../classdominio_1_1clases_1_1_slope_one.html',1,'dominio::clases']]]
];
