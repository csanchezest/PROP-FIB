var searchData=
[
  ['language_0',['language',['../classdominio_1_1clases_1_1_cjt__items.html#a0319618c483d0ad3382d797a8bd797f0',1,'dominio.clases.Cjt_items.language()'],['../classdominio_1_1controladores_1_1_ctrl_gestio_items.html#ac203f0a7171ca464465cab2e08c81f40',1,'dominio.controladores.CtrlGestioItems.language()']]],
  ['loaddataset_1',['loadDataset',['../classdominio_1_1controladores_1_1_controlador_dominio.html#a6da7d115c6c370955ffd02ee3b27412b',1,'dominio.controladores.ControladorDominio.loadDataset()'],['../classdominio_1_1controladores_1_1_ctrl_gestio_items.html#a3e49bff754be094321eb9bae048cb186',1,'dominio.controladores.CtrlGestioItems.loadDataset()']]],
  ['log_2',['log',['../classdominio_1_1clases_1_1_avaluacio.html#a6c3beb045b7f416a0494eac6127db2bf',1,'dominio::clases::Avaluacio']]]
];
