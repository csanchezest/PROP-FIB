var searchData=
[
  ['u_0',['u',['../classdominio_1_1controladores_1_1_ctrl_gestio_usuaris.html#a3f20184edb608c74c561f586c8b4d65b',1,'dominio::controladores::CtrlGestioUsuaris']]],
  ['unknown_1',['unknown',['../classdominio_1_1controladores_1_1_ctrl_gestio_items.html#aff59cd032aaca30a6a2e2a49cc6d6cb2',1,'dominio::controladores::CtrlGestioItems']]],
  ['unknownvals_2',['unknownVals',['../classdominio_1_1controladores_1_1_ctrl_gestio_items.html#a12f9ef37cfe6b861bcad4a4758e92c4e',1,'dominio::controladores::CtrlGestioItems']]],
  ['user_3',['user',['../classdominio_1_1clases_1_1_algorisme.html#aee088dc070748fe366f2068b0a512981',1,'dominio.clases.Algorisme.user()'],['../classdominio_1_1clases_1_1_recomendacion.html#a4e621a2d68584fb5e13a43440207569d',1,'dominio.clases.Recomendacion.user()'],['../classdominio_1_1controladores_1_1_ctrl_gestio_usuaris.html#ab7f06c34e3e6cf92c96e419f3990f6fb',1,'dominio.controladores.CtrlGestioUsuaris.user()']]],
  ['userid_4',['userId',['../classdominio_1_1clases_1_1_usuari.html#a92bc630088dcbac019ab4a4365241af5',1,'dominio.clases.Usuari.userId()'],['../classdominio_1_1controladores_1_1_ctrl_gestio_usuaris.html#a13076b71af8a47fb6c4e9c01bd8dd841',1,'dominio.controladores.CtrlGestioUsuaris.userId()']]],
  ['users_5',['users',['../classdominio_1_1clases_1_1_algorisme.html#aa2a6296923e364755e6d0efaaaa4b2c2',1,'dominio.clases.Algorisme.users()'],['../classdominio_1_1clases_1_1_recomendacion.html#af0a75865b4bb1a6543ec1811caa01898',1,'dominio.clases.Recomendacion.users()'],['../classdominio_1_1controladores_1_1_ctrl_gestio_usuaris.html#a05f1521131e1fcf09b8842ddbc5384e7',1,'dominio.controladores.CtrlGestioUsuaris.users()']]],
  ['usuaris_6',['usuaris',['../classdominio_1_1clases_1_1_cluster.html#a78831373efa93d1ea08e3b44e3dee710',1,'dominio::clases::Cluster']]]
];
