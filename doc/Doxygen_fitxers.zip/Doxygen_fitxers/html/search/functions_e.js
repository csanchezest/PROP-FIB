var searchData=
[
  ['usuari_0',['Usuari',['../classdominio_1_1clases_1_1_usuari.html#a8348aacd4be6388d766827d988961213',1,'dominio.clases.Usuari.Usuari(int userId)'],['../classdominio_1_1clases_1_1_usuari.html#a6092345e3c2154f0d5858e4cfd9709e0',1,'dominio.clases.Usuari.Usuari(int userId, HashMap&lt; Item, Double &gt; ratings)']]]
];
