var searchData=
[
  ['headerindexes_0',['HeaderIndexes',['../classdominio_1_1clases_1_1_cjt__items.html#a3bc7a77743f28b5cc669216d45fde816',1,'dominio::clases::Cjt_items']]],
  ['headers_1',['headers',['../classdominio_1_1clases_1_1_cjt__items.html#a17e847a446d949c4b6a78dd7837fcd5e',1,'dominio::clases::Cjt_items']]]
];
