var searchData=
[
  ['wordfrequencies_0',['wordFrequencies',['../classdominio_1_1clases_1_1_item.html#ab6724f18aefb7822c36b8b2c6476dd46',1,'dominio::clases::Item']]]
];
