var searchData=
[
  ['isboolean_0',['isBoolean',['../classdominio_1_1clases_1_1_cjt__items.html#a5e45405cdc21090b4deea14cfe2b0fed',1,'dominio::clases::Cjt_items']]],
  ['isdatasetcargado_1',['isDatasetCargado',['../classdominio_1_1controladores_1_1_controlador_dominio.html#a5fd2e4251a3e708e5524d9180b8f6cfe',1,'dominio.controladores.ControladorDominio.isDatasetCargado()'],['../classdominio_1_1controladores_1_1_ctrl_gestio_items.html#a6f68c681890b01f6d113c4025d64c74a',1,'dominio.controladores.CtrlGestioItems.isDatasetCargado()']]],
  ['isdate_2',['isDate',['../classdominio_1_1clases_1_1_cjt__items.html#a2f771b5a26c115a5d3d6380e6fd3cfce',1,'dominio::clases::Cjt_items']]],
  ['isdouble_3',['isDouble',['../classdominio_1_1clases_1_1_cjt__items.html#a28471f1bcf4fa41b2555c115de5690cd',1,'dominio::clases::Cjt_items']]],
  ['isinteger_4',['isInteger',['../classdominio_1_1clases_1_1_cjt__items.html#a2d05253f4a2145086535b3ef096d4372',1,'dominio::clases::Cjt_items']]],
  ['item_5',['Item',['../classdominio_1_1clases_1_1_item.html#ae4ad22e17fcba45f5bcfddf105dd8c6a',1,'dominio.clases.Item.Item()'],['../classdominio_1_1clases_1_1_item.html#ad0931eb129b40f5862300becefdda2bd',1,'dominio.clases.Item.Item(String id)']]]
];
