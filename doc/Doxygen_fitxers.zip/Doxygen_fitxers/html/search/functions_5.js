var searchData=
[
  ['hashcode_0',['hashCode',['../classdominio_1_1clases_1_1_item.html#ade0201c0a941de4d068369fca52ad0c7',1,'dominio.clases.Item.hashCode()'],['../classdominio_1_1clases_1_1_usuari.html#a3d33531682f11a92a3b982aeab82cc69',1,'dominio.clases.Usuari.hashCode()']]],
  ['hybrid_1',['Hybrid',['../classdominio_1_1clases_1_1_hybrid.html#a2d58a16b774675d52ad4afe0f360b206',1,'dominio.clases.Hybrid.Hybrid()'],['../classdominio_1_1clases_1_1_recomendacion.html#ac4ac3a1e3275bed35491f1609928aa8f',1,'dominio.clases.Recomendacion.Hybrid()']]]
];
