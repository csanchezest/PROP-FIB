var searchData=
[
  ['dataset_0',['dataset',['../classdominio_1_1clases_1_1_algorisme.html#a966a79e4751cb23c2f8a0537511cd94e',1,'dominio.clases.Algorisme.dataset()'],['../classdominio_1_1clases_1_1_recomendacion.html#ab92c75a13f1340498ad0302bf9e65955',1,'dominio.clases.Recomendacion.dataset()'],['../classdominio_1_1controladores_1_1_ctrl_gestio_items.html#abdf4d96c56577c6016aba70176dae1eb',1,'dominio.controladores.CtrlGestioItems.dataset()']]],
  ['dateat_1',['dateAt',['../classdominio_1_1clases_1_1_content_based.html#a73e0142249ad740b54efef71f2078fb0',1,'dominio.clases.ContentBased.dateAt()'],['../classdominio_1_1clases_1_1_distance_items.html#abf3ccc78946f2ab97326949c1c172fe7',1,'dominio.clases.DistanceItems.dateAt()'],['../classdominio_1_1clases_1_1_recomendacion.html#a2f8b33c69cf4197a2f813fedfaff666c',1,'dominio.clases.Recomendacion.dateAt()']]],
  ['dateatt_2',['DateAtt',['../classdominio_1_1clases_1_1_item.html#ac12226043bed2b5b59b0f2188a73e9d6',1,'dominio::clases::Item']]],
  ['dateattrindexes_3',['DateAttrIndexes',['../classdominio_1_1clases_1_1_cjt__items.html#aa12db33878fd1faf2893bca7bfac6ffe',1,'dominio::clases::Cjt_items']]],
  ['doubat_4',['doubAt',['../classdominio_1_1clases_1_1_content_based.html#a6340ab091377a0d056cfd20119370b2b',1,'dominio.clases.ContentBased.doubAt()'],['../classdominio_1_1clases_1_1_distance_items.html#a1b3007336c7ff85e39f821b0d5b15887',1,'dominio.clases.DistanceItems.doubAt()'],['../classdominio_1_1clases_1_1_recomendacion.html#a90cd4396fde9e52425bc1935299c5d1c',1,'dominio.clases.Recomendacion.doubAt()']]],
  ['doubleatt_5',['DoubleAtt',['../classdominio_1_1clases_1_1_item.html#a671a2fe3283d7db93af0e494dc03317b',1,'dominio::clases::Item']]],
  ['doubleattrindexes_6',['DoubleAttrIndexes',['../classdominio_1_1clases_1_1_cjt__items.html#a1f3ae727771915dd0688f474e2df16f6',1,'dominio::clases::Cjt_items']]]
];
