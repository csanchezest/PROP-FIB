var searchData=
[
  ['b_0',['b',['../classdominio_1_1clases_1_1_distance_items.html#ad95d8d84592b10909e2296b159c2a384',1,'dominio::clases::DistanceItems']]],
  ['bat_1',['bAt',['../classdominio_1_1clases_1_1_content_based.html#afc96c69348d58366f6b3d868a073a01f',1,'dominio.clases.ContentBased.bAt()'],['../classdominio_1_1clases_1_1_distance_items.html#a80892aaf007ba663185d75b5e397cd1d',1,'dominio.clases.DistanceItems.bAt()'],['../classdominio_1_1clases_1_1_recomendacion.html#adf6d7e912a6964127009e63cba4397b8',1,'dominio.clases.Recomendacion.bAt()']]],
  ['booleanatt_2',['BooleanAtt',['../classdominio_1_1clases_1_1_item.html#abdbf2f38bbb32e692a6312e3ce6222f4',1,'dominio::clases::Item']]],
  ['booleanattrindexes_3',['BooleanAttrIndexes',['../classdominio_1_1clases_1_1_cjt__items.html#a01777c9c9ac607b6e189dceb789bd10a',1,'dominio::clases::Cjt_items']]]
];
