var searchData=
[
  ['recolocar_0',['recolocar',['../classdominio_1_1clases_1_1_centroid.html#abbf5337fa6de3789052b00b4897993a7',1,'dominio::clases::Centroid']]],
  ['recomendacion_1',['Recomendacion',['../classdominio_1_1clases_1_1_recomendacion.html#a650c7287da0e8aa712d2fa9d9f90300f',1,'dominio::clases::Recomendacion']]],
  ['recommendations_2',['recommendations',['../classdominio_1_1clases_1_1_collaborative.html#a2c88acf8217278a6dcdde01d87e11c41',1,'dominio::clases::Collaborative']]],
  ['recommended_5fitems_3',['recommended_items',['../classdominio_1_1clases_1_1_content_based.html#a85943724cd710fd0ab3d14159604589a',1,'dominio.clases.ContentBased.recommended_items()'],['../classdominio_1_1clases_1_1_hybrid.html#a7e9feca1edf15f6368e1fa25f9590335',1,'dominio.clases.Hybrid.recommended_items()']]],
  ['relocatecentroids_4',['relocateCentroids',['../classdominio_1_1clases_1_1_collaborative.html#a542e8d67b9d573784a48b90552527254',1,'dominio::clases::Collaborative']]],
  ['resetupdatedfile_5',['resetUpdatedFile',['../classdominio_1_1controladores_1_1_controlador_dominio.html#a8f6c8ae9fc9e08f8b2519f00b2c77d5d',1,'dominio::controladores::ControladorDominio']]]
];
