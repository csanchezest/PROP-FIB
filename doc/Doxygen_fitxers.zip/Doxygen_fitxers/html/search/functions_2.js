var searchData=
[
  ['dcg_0',['DCG',['../classdominio_1_1clases_1_1_avaluacio.html#a6097e0538c2f66438f1d09f8f6585cec',1,'dominio::clases::Avaluacio']]],
  ['distanceitems_1',['DistanceItems',['../classdominio_1_1clases_1_1_distance_items.html#a6de7f2f69702140ee86ae2d79a58e5b8',1,'dominio::clases::DistanceItems']]],
  ['distbetweenbool_2',['distBetweenBool',['../classdominio_1_1clases_1_1_distance_items.html#a63e34fa55e68f6198cd5d589b2a7f070',1,'dominio::clases::DistanceItems']]],
  ['distbetweencategory_3',['distBetweenCategory',['../classdominio_1_1clases_1_1_distance_items.html#ab6305114ffcc1ce0438d2eaca4c028f6',1,'dominio::clases::DistanceItems']]],
  ['distbetweendate_4',['distBetweenDate',['../classdominio_1_1clases_1_1_distance_items.html#ae119f4dc0e73a4a9aa11b19e1b521781',1,'dominio::clases::DistanceItems']]],
  ['distbetweendouble_5',['distBetweenDouble',['../classdominio_1_1clases_1_1_distance_items.html#a69e4e193ba4de312ddfb2e3c0475497d',1,'dominio::clases::DistanceItems']]],
  ['distbetweenint_6',['distBetweenInt',['../classdominio_1_1clases_1_1_distance_items.html#a4ef0c1870132ad8ac1081c8305af8281',1,'dominio::clases::DistanceItems']]],
  ['distbetweenstring_7',['distBetweenString',['../classdominio_1_1clases_1_1_distance_items.html#a116b7b8812944dac7d6be4f9f67de584',1,'dominio::clases::DistanceItems']]],
  ['distbetweentexttest_8',['distBetweenTextTest',['../classdominio_1_1controladores_1_1_distance_items_unit_test.html#afb4058ff580a6bb533f77cb07640e45e',1,'dominio::controladores::DistanceItemsUnitTest']]]
];
