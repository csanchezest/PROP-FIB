var searchData=
[
  ['usuari_0',['Usuari',['../classdominio_1_1clases_1_1_usuari.html',1,'dominio::clases']]]
];
