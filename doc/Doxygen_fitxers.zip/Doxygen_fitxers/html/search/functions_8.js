var searchData=
[
  ['makerecomendation_0',['makeRecomendation',['../classdominio_1_1controladores_1_1_controlador_dominio.html#a6ff05c804337cead371dd26055f50685',1,'dominio.controladores.ControladorDominio.makeRecomendation()'],['../classdominio_1_1controladores_1_1_ctrl_gestio_recomanacio.html#ac04ae71a3c35216ef3d135607b89cc80',1,'dominio.controladores.CtrlGestioRecomanacio.makeRecomendation()']]],
  ['maxdistanceusercentroid_1',['maxDistanceUserCentroid',['../classdominio_1_1clases_1_1_collaborative.html#aedf00b2f0f3420d45a77188f41075bc3',1,'dominio::clases::Collaborative']]]
];
