var searchData=
[
  ['item_0',['Item',['../classdominio_1_1clases_1_1_item.html',1,'dominio::clases']]]
];
