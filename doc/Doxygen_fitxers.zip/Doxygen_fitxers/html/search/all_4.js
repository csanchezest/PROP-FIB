var searchData=
[
  ['ejecuta_5fk_5fmeans_0',['ejecuta_k_means',['../classdominio_1_1clases_1_1_collaborative.html#a03a095d618fe44646af54f4c588f9730',1,'dominio::clases::Collaborative']]],
  ['eliminar_1',['eliminar',['../classdominio_1_1clases_1_1_centroid.html#a9f13b81d164983cbd93eb9ed51929bb6',1,'dominio::clases::Centroid']]],
  ['eliminatefromcluster_2',['eliminateFromCluster',['../classdominio_1_1clases_1_1_collaborative.html#ab49cbd617aa3a3eb96f8cbeca19952fc',1,'dominio::clases::Collaborative']]],
  ['equals_3',['equals',['../classdominio_1_1clases_1_1_item.html#a0ddad3d76757e3f015f212526f941ec5',1,'dominio.clases.Item.equals()'],['../classdominio_1_1clases_1_1_usuari.html#adbf71c35aed9a64dab52259555301b41',1,'dominio.clases.Usuari.equals()']]],
  ['existeitem_4',['existeItem',['../classdominio_1_1controladores_1_1_controlador_dominio.html#a4c1944df3939ff8f1ace89df1a0ca7e5',1,'dominio.controladores.ControladorDominio.existeItem()'],['../classdominio_1_1controladores_1_1_ctrl_gestio_items.html#addf1380062f663db03317b90ec59672c',1,'dominio.controladores.CtrlGestioItems.existeItem()']]],
  ['existeusuario_5',['existeUsuario',['../classdominio_1_1controladores_1_1_controlador_dominio.html#a92f189b879e34147fcce9caa430eb267',1,'dominio.controladores.ControladorDominio.existeUsuario()'],['../classdominio_1_1controladores_1_1_ctrl_gestio_usuaris.html#ab03d620f033477d6bb928226d11f33b1',1,'dominio.controladores.CtrlGestioUsuaris.existeUsuario()']]]
];
