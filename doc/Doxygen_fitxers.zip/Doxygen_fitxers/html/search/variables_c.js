var searchData=
[
  ['padre_0',['padre',['../classdominio_1_1controladores_1_1_controlador_dominio.html#a6143f76ebdb7f9a025eb970428c41490',1,'dominio.controladores.ControladorDominio.padre()'],['../classdominio_1_1controladores_1_1_ctrl_gestio_items.html#a9375e76315b7c3a41926ab9fe8e150ab',1,'dominio.controladores.CtrlGestioItems.padre()']]],
  ['predictions_1',['predictions',['../classdominio_1_1clases_1_1_slope_one.html#a2b932364f1890dd0c3ff5a7f250f29bb',1,'dominio::clases::SlopeOne']]]
];
