var searchData=
[
  ['recomendacion_0',['Recomendacion',['../classdominio_1_1clases_1_1_recomendacion.html',1,'dominio::clases']]]
];
