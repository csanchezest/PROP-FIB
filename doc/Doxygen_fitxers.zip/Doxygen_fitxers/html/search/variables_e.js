var searchData=
[
  ['stringatt_0',['StringAtt',['../classdominio_1_1clases_1_1_item.html#a55f8b33c9fab79b55904e62a5c06208f',1,'dominio::clases::Item']]],
  ['stringattrindexes_1',['StringAttrIndexes',['../classdominio_1_1clases_1_1_cjt__items.html#a344898a8ee26091d7da86caf39aaf20f',1,'dominio::clases::Cjt_items']]]
];
