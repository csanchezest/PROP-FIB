var searchData=
[
  ['centroid_0',['Centroid',['../classdominio_1_1clases_1_1_centroid.html',1,'dominio::clases']]],
  ['cjt_5fitems_1',['Cjt_items',['../classdominio_1_1clases_1_1_cjt__items.html',1,'dominio::clases']]],
  ['cluster_2',['Cluster',['../classdominio_1_1clases_1_1_cluster.html',1,'dominio::clases']]],
  ['collaborative_3',['Collaborative',['../classdominio_1_1clases_1_1_collaborative.html',1,'dominio::clases']]],
  ['contentbased_4',['ContentBased',['../classdominio_1_1clases_1_1_content_based.html',1,'dominio::clases']]],
  ['controladordominio_5',['ControladorDominio',['../classdominio_1_1controladores_1_1_controlador_dominio.html',1,'dominio::controladores']]],
  ['ctrlgestioitems_6',['CtrlGestioItems',['../classdominio_1_1controladores_1_1_ctrl_gestio_items.html',1,'dominio::controladores']]],
  ['ctrlgestiorecomanacio_7',['CtrlGestioRecomanacio',['../classdominio_1_1controladores_1_1_ctrl_gestio_recomanacio.html',1,'dominio::controladores']]],
  ['ctrlgestiousuaris_8',['CtrlGestioUsuaris',['../classdominio_1_1controladores_1_1_ctrl_gestio_usuaris.html',1,'dominio::controladores']]]
];
