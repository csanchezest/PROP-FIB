var searchData=
[
  ['random_0',['random',['../classdominio_1_1clases_1_1_collaborative.html#a82492a33d04c759335cdb3684df61b9b',1,'dominio::clases::Collaborative']]],
  ['rateditems_1',['ratedItems',['../classdominio_1_1clases_1_1_content_based.html#ac79c5546f6c70b0f5fa5edcd529c38ca',1,'dominio.clases.ContentBased.ratedItems()'],['../classdominio_1_1clases_1_1_usuari.html#ac0f1283dfef97d10842951aabbfeebce',1,'dominio.clases.Usuari.ratedItems()']]],
  ['ratings_2',['ratings',['../classdominio_1_1clases_1_1_algorisme.html#a9c9055131097eeb0052bc6da89a59475',1,'dominio.clases.Algorisme.ratings()'],['../classdominio_1_1clases_1_1_recomendacion.html#ad8262d7c6c7fa7d301d2e622c7258280',1,'dominio.clases.Recomendacion.ratings()'],['../classdominio_1_1controladores_1_1_ctrl_gestio_items.html#a055c279bb022139e1802058f40657422',1,'dominio.controladores.CtrlGestioItems.ratings()']]],
  ['recolocar_3',['recolocar',['../classdominio_1_1clases_1_1_centroid.html#abbf5337fa6de3789052b00b4897993a7',1,'dominio::clases::Centroid']]],
  ['recomendacion_4',['Recomendacion',['../classdominio_1_1clases_1_1_recomendacion.html',1,'dominio.clases.Recomendacion'],['../classdominio_1_1clases_1_1_recomendacion.html#a650c7287da0e8aa712d2fa9d9f90300f',1,'dominio.clases.Recomendacion.Recomendacion()']]],
  ['recomendacion_2ejava_5',['Recomendacion.java',['../_recomendacion_8java.html',1,'']]],
  ['recommendations_6',['recommendations',['../classdominio_1_1clases_1_1_collaborative.html#a2c88acf8217278a6dcdde01d87e11c41',1,'dominio::clases::Collaborative']]],
  ['recommended_5fitems_7',['recommended_items',['../classdominio_1_1clases_1_1_content_based.html#a85943724cd710fd0ab3d14159604589a',1,'dominio.clases.ContentBased.recommended_items()'],['../classdominio_1_1clases_1_1_hybrid.html#a7e9feca1edf15f6368e1fa25f9590335',1,'dominio.clases.Hybrid.recommended_items()']]],
  ['relocatecentroids_8',['relocateCentroids',['../classdominio_1_1clases_1_1_collaborative.html#a542e8d67b9d573784a48b90552527254',1,'dominio::clases::Collaborative']]],
  ['resetupdatedfile_9',['resetUpdatedFile',['../classdominio_1_1controladores_1_1_controlador_dominio.html#a8f6c8ae9fc9e08f8b2519f00b2c77d5d',1,'dominio::controladores::ControladorDominio']]]
];
