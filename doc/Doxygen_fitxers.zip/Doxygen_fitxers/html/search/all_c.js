var searchData=
[
  ['nearest_5fdist_0',['nearest_dist',['../classdominio_1_1clases_1_1_usuari.html#a6e7d8a4717e8ebe7f008a55cd55ab2fc',1,'dominio::clases::Usuari']]],
  ['nearestcentroid_1',['nearestCentroid',['../classdominio_1_1clases_1_1_collaborative.html#a5d9aac320718b1fc379c782e20247392',1,'dominio::clases::Collaborative']]]
];
