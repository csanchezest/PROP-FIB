var searchData=
[
  ['algorisme_2ejava_0',['Algorisme.java',['../_algorisme_8java.html',1,'']]],
  ['attributedata_2ejava_1',['AttributeData.java',['../_attribute_data_8java.html',1,'']]],
  ['avaluacio_2ejava_2',['Avaluacio.java',['../_avaluacio_8java.html',1,'']]]
];
