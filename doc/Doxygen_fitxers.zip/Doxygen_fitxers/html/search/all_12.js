var searchData=
[
  ['u_0',['u',['../classdominio_1_1controladores_1_1_ctrl_gestio_usuaris.html#a3f20184edb608c74c561f586c8b4d65b',1,'dominio::controladores::CtrlGestioUsuaris']]],
  ['unknown_1',['unknown',['../classdominio_1_1controladores_1_1_ctrl_gestio_items.html#aff59cd032aaca30a6a2e2a49cc6d6cb2',1,'dominio::controladores::CtrlGestioItems']]],
  ['unknownvals_2',['unknownVals',['../classdominio_1_1controladores_1_1_ctrl_gestio_items.html#a12f9ef37cfe6b861bcad4a4758e92c4e',1,'dominio::controladores::CtrlGestioItems']]],
  ['updatedoublemedianmaps_3',['updateDoubleMedianMaps',['../classdominio_1_1clases_1_1_cjt__items.html#a71eaae51b393f8481b3cc8df0036a057',1,'dominio::clases::Cjt_items']]],
  ['updateintmedianmaps_4',['updateIntMedianMaps',['../classdominio_1_1clases_1_1_cjt__items.html#a3e130927e2cea422e6f2c9cca1d889a3',1,'dominio::clases::Cjt_items']]],
  ['updatelongmedianmaps_5',['updateLongMedianMaps',['../classdominio_1_1clases_1_1_cjt__items.html#a6d2af8fdbe3e98ca58a468080be6d2b1',1,'dominio::clases::Cjt_items']]],
  ['user_6',['user',['../classdominio_1_1clases_1_1_algorisme.html#aee088dc070748fe366f2068b0a512981',1,'dominio.clases.Algorisme.user()'],['../classdominio_1_1clases_1_1_recomendacion.html#a4e621a2d68584fb5e13a43440207569d',1,'dominio.clases.Recomendacion.user()'],['../classdominio_1_1controladores_1_1_ctrl_gestio_usuaris.html#ab7f06c34e3e6cf92c96e419f3990f6fb',1,'dominio.controladores.CtrlGestioUsuaris.user()']]],
  ['userhasratings_7',['userHasRatings',['../classdominio_1_1controladores_1_1_controlador_dominio.html#ac6763b842b9cdc7790394ecb30da9541',1,'dominio::controladores::ControladorDominio']]],
  ['userid_8',['userId',['../classdominio_1_1clases_1_1_usuari.html#a92bc630088dcbac019ab4a4365241af5',1,'dominio.clases.Usuari.userId()'],['../classdominio_1_1controladores_1_1_ctrl_gestio_usuaris.html#a13076b71af8a47fb6c4e9c01bd8dd841',1,'dominio.controladores.CtrlGestioUsuaris.userId()']]],
  ['users_9',['users',['../classdominio_1_1controladores_1_1_ctrl_gestio_usuaris.html#a05f1521131e1fcf09b8842ddbc5384e7',1,'dominio.controladores.CtrlGestioUsuaris.users()'],['../classdominio_1_1clases_1_1_algorisme.html#aa2a6296923e364755e6d0efaaaa4b2c2',1,'dominio.clases.Algorisme.users()'],['../classdominio_1_1clases_1_1_recomendacion.html#af0a75865b4bb1a6543ec1811caa01898',1,'dominio.clases.Recomendacion.users()']]],
  ['usuari_10',['Usuari',['../classdominio_1_1clases_1_1_usuari.html',1,'dominio.clases.Usuari'],['../classdominio_1_1clases_1_1_usuari.html#a8348aacd4be6388d766827d988961213',1,'dominio.clases.Usuari.Usuari(int userId)'],['../classdominio_1_1clases_1_1_usuari.html#a0355163b1d1445f6e7007b2d4ec80ba7',1,'dominio.clases.Usuari.Usuari(Usuari u)'],['../classdominio_1_1clases_1_1_usuari.html#a6092345e3c2154f0d5858e4cfd9709e0',1,'dominio.clases.Usuari.Usuari(int userId, HashMap&lt; Item, Double &gt; ratings)']]],
  ['usuari_2ejava_11',['Usuari.java',['../_usuari_8java.html',1,'']]],
  ['usuariopertenecearatings_12',['usuarioPerteneceARatings',['../classdominio_1_1controladores_1_1_ctrl_gestio_items.html#a373ed518f57dcb1d3cca16eff7ffa5cd',1,'dominio::controladores::CtrlGestioItems']]],
  ['usuaris_13',['usuaris',['../classdominio_1_1clases_1_1_cluster.html#a78831373efa93d1ea08e3b44e3dee710',1,'dominio::clases::Cluster']]]
];
