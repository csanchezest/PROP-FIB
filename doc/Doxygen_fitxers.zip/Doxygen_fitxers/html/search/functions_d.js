var searchData=
[
  ['updatedoublemedianmaps_0',['updateDoubleMedianMaps',['../classdominio_1_1clases_1_1_cjt__items.html#a71eaae51b393f8481b3cc8df0036a057',1,'dominio::clases::Cjt_items']]],
  ['updateintmedianmaps_1',['updateIntMedianMaps',['../classdominio_1_1clases_1_1_cjt__items.html#a3e130927e2cea422e6f2c9cca1d889a3',1,'dominio::clases::Cjt_items']]],
  ['updatelongmedianmaps_2',['updateLongMedianMaps',['../classdominio_1_1clases_1_1_cjt__items.html#a6d2af8fdbe3e98ca58a468080be6d2b1',1,'dominio::clases::Cjt_items']]],
  ['userhasratings_3',['userHasRatings',['../classdominio_1_1controladores_1_1_controlador_dominio.html#ac6763b842b9cdc7790394ecb30da9541',1,'dominio::controladores::ControladorDominio']]],
  ['usuari_4',['Usuari',['../classdominio_1_1clases_1_1_usuari.html#a8348aacd4be6388d766827d988961213',1,'dominio.clases.Usuari.Usuari(int userId)'],['../classdominio_1_1clases_1_1_usuari.html#a0355163b1d1445f6e7007b2d4ec80ba7',1,'dominio.clases.Usuari.Usuari(Usuari u)'],['../classdominio_1_1clases_1_1_usuari.html#a6092345e3c2154f0d5858e4cfd9709e0',1,'dominio.clases.Usuari.Usuari(int userId, HashMap&lt; Item, Double &gt; ratings)']]],
  ['usuariopertenecearatings_5',['usuarioPerteneceARatings',['../classdominio_1_1controladores_1_1_ctrl_gestio_items.html#a373ed518f57dcb1d3cca16eff7ffa5cd',1,'dominio::controladores::CtrlGestioItems']]]
];
