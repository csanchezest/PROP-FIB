var searchData=
[
  ['a_0',['a',['../classdominio_1_1clases_1_1_distance_items.html#ab349ffb7fc18489710b44569cccb298c',1,'dominio::clases::DistanceItems']]],
  ['aux_1',['aux',['../classdominio_1_1controladores_1_1_ctrl_gestio_items.html#a40540a95c9315debd31029c53cec06d7',1,'dominio::controladores::CtrlGestioItems']]]
];
