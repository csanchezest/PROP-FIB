var searchData=
[
  ['usuari_2ejava_0',['Usuari.java',['../_usuari_8java.html',1,'']]]
];
