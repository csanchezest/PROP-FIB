var searchData=
[
  ['valoraciones_0',['valoraciones',['../classdominio_1_1clases_1_1_centroid.html#af5ac5c4fad0ee750fe732f5f6ececef0',1,'dominio.clases.Centroid.valoraciones()'],['../classdominio_1_1controladores_1_1_ctrl_gestio_recomanacio.html#a585138303ff3193cc1d31512908e4ffe',1,'dominio.controladores.CtrlGestioRecomanacio.valoraciones()']]],
  ['vals_1',['vals',['../classdominio_1_1controladores_1_1_ctrl_gestio_items.html#a2c8af351ec090618e29d533400da7785',1,'dominio::controladores::CtrlGestioItems']]]
];
