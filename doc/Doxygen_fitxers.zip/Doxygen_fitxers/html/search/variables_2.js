var searchData=
[
  ['catat_0',['catAt',['../classdominio_1_1clases_1_1_content_based.html#a58fc6e587f94625f55819aafddd62141',1,'dominio.clases.ContentBased.catAt()'],['../classdominio_1_1clases_1_1_distance_items.html#a11c7b0ff87dd0a5073d8bf7f739bb0e4',1,'dominio.clases.DistanceItems.catAt()'],['../classdominio_1_1clases_1_1_recomendacion.html#a9f89371f89bded60bc6ed3e9f373d27e',1,'dominio.clases.Recomendacion.catAt()']]],
  ['catattr_1',['CatAttr',['../classdominio_1_1clases_1_1_item.html#af97689e82026b39311c2d0cd7ccaa6ef',1,'dominio::clases::Item']]],
  ['categoricalatt_5fpsc_5fbits_2',['CategoricalAtt_Psc_bits',['../classdominio_1_1clases_1_1_item.html#a621e4760412988731146647541beda62',1,'dominio::clases::Item']]],
  ['categoricalattrindexes_3',['CategoricalAttrIndexes',['../classdominio_1_1clases_1_1_cjt__items.html#a12541757e1a2698a1fa409548919ec4f',1,'dominio::clases::Cjt_items']]],
  ['centroid_4',['centroid',['../classdominio_1_1clases_1_1_centroid.html#a4491f8b97812b71de75bf68a33aea36a',1,'dominio.clases.Centroid.centroid()'],['../classdominio_1_1clases_1_1_cluster.html#a0000a0fe64e1924f3875ba3f05a959b8',1,'dominio.clases.Cluster.centroid()'],['../classdominio_1_1clases_1_1_usuari.html#a555b1472ab3a3659e700302165e84f33',1,'dominio.clases.Usuari.centroid()']]],
  ['centroid_5fnumber_5',['centroid_number',['../classdominio_1_1clases_1_1_centroid.html#a5dee63e80fedc858e13c72c1f8733611',1,'dominio::clases::Centroid']]],
  ['centroid_5fuser_5fid_6',['centroid_user_id',['../classdominio_1_1clases_1_1_centroid.html#a76017c3be2e6bec371118caee0862667',1,'dominio::clases::Centroid']]],
  ['collaborative_7',['collaborative',['../classdominio_1_1clases_1_1_hybrid.html#a27b71d32b89eaf0db4187dae5d4265ec',1,'dominio::clases::Hybrid']]],
  ['content_8',['content',['../classdominio_1_1clases_1_1_hybrid.html#afe7d7217c1937b73cac0aefe99cbb0ce',1,'dominio::clases::Hybrid']]],
  ['ctrlgestioitems_9',['ctrlGestioItems',['../classdominio_1_1controladores_1_1_controlador_dominio.html#ab58bba57be5096151e4d4447bea5c8b6',1,'dominio::controladores::ControladorDominio']]],
  ['ctrlgestiorecomanacio_10',['ctrlGestioRecomanacio',['../classdominio_1_1controladores_1_1_controlador_dominio.html#ab6754bee9f5b4d9842b1446593d1f6e7',1,'dominio::controladores::ControladorDominio']]],
  ['ctrlusuaris_11',['ctrlUsuaris',['../classdominio_1_1controladores_1_1_controlador_dominio.html#a1e8b7f856b6e0471cec288b9618a2737',1,'dominio::controladores::ControladorDominio']]]
];
