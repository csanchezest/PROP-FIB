var searchData=
[
  ['times_0',['times',['../classdominio_1_1clases_1_1_centroid.html#aef41c2eaff0f0280ff9c6bae3aafec88',1,'dominio::clases::Centroid']]],
  ['type_1',['type',['../classdominio_1_1clases_1_1_attribute_data.html#a86da8b82d4eb9373f611cd85034a0874',1,'dominio::clases::AttributeData']]]
];
