var searchData=
[
  ['a_0',['a',['../classdominio_1_1clases_1_1_distance_items.html#ab349ffb7fc18489710b44569cccb298c',1,'dominio::clases::DistanceItems']]],
  ['addrateditems_1',['addRatedItems',['../classdominio_1_1clases_1_1_usuari.html#a7be6538c33a7ce2d5ad998032e9ff4e8',1,'dominio::clases::Usuari']]],
  ['addusuari_2',['addUsuari',['../classdominio_1_1clases_1_1_cluster.html#a7a2e7dd6793e35853c4d43b42963fb87',1,'dominio::clases::Cluster']]],
  ['algorisme_3',['Algorisme',['../classdominio_1_1clases_1_1_algorisme.html#af2cea62ddcce94fccda105803f915b5b',1,'dominio.clases.Algorisme.Algorisme(Usuari user, Cjt_items dataset, HashMap&lt; Item, ArrayList&lt; Double &gt; &gt; ratings)'],['../classdominio_1_1clases_1_1_algorisme.html#aa4fcd0310a6e25c22e5dc3dba4c897cf',1,'dominio.clases.Algorisme.Algorisme()'],['../classdominio_1_1clases_1_1_algorisme.html',1,'dominio.clases.Algorisme']]],
  ['algorisme_2ejava_4',['Algorisme.java',['../_algorisme_8java.html',1,'']]],
  ['almacenarrating_5',['almacenarRating',['../classdominio_1_1controladores_1_1_controlador_dominio.html#a3cb5fcd392cb4209ee263ec9b3aba9eb',1,'dominio::controladores::ControladorDominio']]],
  ['applycentroids_6',['applyCentroids',['../classdominio_1_1clases_1_1_collaborative.html#a26787a80fa20b38cb0b1e3486de530ad',1,'dominio::clases::Collaborative']]],
  ['assigntocluster_7',['assignToCluster',['../classdominio_1_1clases_1_1_collaborative.html#ac4da1ca873616191598d33f849ebc33d',1,'dominio::clases::Collaborative']]],
  ['attributedata_8',['AttributeData',['../classdominio_1_1clases_1_1_attribute_data.html#a99d708b58b834abbb0f6feff03033c37',1,'dominio.clases.AttributeData.AttributeData(int index, String type)'],['../classdominio_1_1clases_1_1_attribute_data.html#aceba902ea124ad3972ad8e8fd350b08c',1,'dominio.clases.AttributeData.AttributeData()'],['../classdominio_1_1clases_1_1_attribute_data.html',1,'dominio.clases.AttributeData']]],
  ['attributedata_2ejava_9',['AttributeData.java',['../_attribute_data_8java.html',1,'']]],
  ['aux_10',['aux',['../classdominio_1_1controladores_1_1_ctrl_gestio_items.html#a40540a95c9315debd31029c53cec06d7',1,'dominio::controladores::CtrlGestioItems']]],
  ['avaluacio_11',['Avaluacio',['../classdominio_1_1clases_1_1_avaluacio.html',1,'dominio::clases']]],
  ['avaluacio_2ejava_12',['Avaluacio.java',['../_avaluacio_8java.html',1,'']]],
  ['average_13',['average',['../classdominio_1_1clases_1_1_collaborative.html#a80dac1e093db8ac2c951429ee26c82bf',1,'dominio::clases::Collaborative']]]
];
