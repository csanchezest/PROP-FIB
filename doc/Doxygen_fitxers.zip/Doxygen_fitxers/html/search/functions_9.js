var searchData=
[
  ['nearestcentroid_0',['nearestCentroid',['../classdominio_1_1clases_1_1_collaborative.html#a5d9aac320718b1fc379c782e20247392',1,'dominio::clases::Collaborative']]]
];
