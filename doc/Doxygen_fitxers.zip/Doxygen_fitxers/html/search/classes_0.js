var searchData=
[
  ['algorisme_0',['Algorisme',['../classdominio_1_1clases_1_1_algorisme.html',1,'dominio::clases']]],
  ['attributedata_1',['AttributeData',['../classdominio_1_1clases_1_1_attribute_data.html',1,'dominio::clases']]],
  ['avaluacio_2',['Avaluacio',['../classdominio_1_1clases_1_1_avaluacio.html',1,'dominio::clases']]]
];
