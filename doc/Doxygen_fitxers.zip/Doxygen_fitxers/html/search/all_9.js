var searchData=
[
  ['k_0',['k',['../classdominio_1_1clases_1_1_content_based.html#a81aee2992403d63aa5c1aeda9d55cb8b',1,'dominio.clases.ContentBased.k()'],['../classdominio_1_1clases_1_1_hybrid.html#a16c9cd77d10a92ce266a8c2497f6ac49',1,'dominio.clases.Hybrid.k()'],['../classdominio_1_1clases_1_1_recomendacion.html#a754f6747833d7138fa4a7a51932b0066',1,'dominio.clases.Recomendacion.k()'],['../classdominio_1_1controladores_1_1_ctrl_gestio_recomanacio.html#a151bacf64acd5934e90c494d4c91ee1c',1,'dominio.controladores.CtrlGestioRecomanacio.k()']]],
  ['known_1',['known',['../classdominio_1_1controladores_1_1_ctrl_gestio_items.html#ac697fe6b7bf9fce8a5047e338f27d8aa',1,'dominio::controladores::CtrlGestioItems']]],
  ['knownvals_2',['knownVals',['../classdominio_1_1controladores_1_1_ctrl_gestio_items.html#a297f6390795bf7f6345042b18e827653',1,'dominio::controladores::CtrlGestioItems']]]
];
