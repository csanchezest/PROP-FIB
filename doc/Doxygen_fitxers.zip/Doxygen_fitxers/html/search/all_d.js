var searchData=
[
  ['otherattrindexes_0',['OtherAttrIndexes',['../classdominio_1_1clases_1_1_cjt__items.html#a36eacd59a4b927c6b13fb1604afc7b14',1,'dominio::clases::Cjt_items']]]
];
