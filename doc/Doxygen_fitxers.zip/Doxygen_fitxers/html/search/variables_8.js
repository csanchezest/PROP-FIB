var searchData=
[
  ['language_0',['language',['../classdominio_1_1clases_1_1_cjt__items.html#a0319618c483d0ad3382d797a8bd797f0',1,'dominio.clases.Cjt_items.language()'],['../classdominio_1_1controladores_1_1_ctrl_gestio_items.html#ac203f0a7171ca464465cab2e08c81f40',1,'dominio.controladores.CtrlGestioItems.language()']]]
];
